import re
from spotipy.oauth2 import SpotifyClientCredentials
import spotipy
import mysql.connector
import pandas as pd

# Set up Spotify API credentials
sp = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
    client_id='7ae955693f224b679fc0abaad6996b13',  # Replace with your Client ID
    client_secret='a4b9348c27754ccb92abe396752c15c4'  # Replace with your Client Secret
))

# MySQL Database Connection
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '69dan@69',
    'database': 'spotify_db'
}

connection = mysql.connector.connect(**db_config)
cursor = connection.cursor()

# Read track URLs
file_path = "track_urls.txt"
with open(file_path, 'r') as file:
    track_urls = file.readlines()

# Store all track data
all_tracks = []

for track_url in track_urls:
    track_url = track_url.strip()
    try:
        track_id = re.search(r'track/([a-zA-Z0-9]+)', track_url).group(1)
        track = sp.track(track_id)

        track_data = {
            'Track Name': track['name'],
            'Artist': track['artists'][0]['name'],
            'Album': track['album']['name'],
            'Popularity': track['popularity'],
            'Duration (minutes)': track['duration_ms'] / 60000
        }

        # Insert into MySQL
        insert_query = """
        INSERT INTO spotify_tracks (track_name, artist, album, popularity, duration_minutes)
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (
            track_data['Track Name'],
            track_data['Artist'],
            track_data['Album'],
            track_data['Popularity'],
            track_data['Duration (minutes)']
        ))
        connection.commit()

        all_tracks.append(track_data)
        print(f"Inserted: {track_data['Track Name']} by {track_data['Artist']}")

    except Exception as e:
        print(f"Error processing {track_url}: {e}")

# Save to CSV
df = pd.DataFrame(all_tracks)
df.to_csv("spotify_tracks.csv", index=False, encoding="utf-8")
print("All tracks saved to spotify_tracks.csv")

cursor.close()
connection.close()
